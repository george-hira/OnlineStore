﻿using System;
using System.Collections.Generic;

namespace MyStore.Domain;

public partial class Num
{
    public int N { get; set; }
}
