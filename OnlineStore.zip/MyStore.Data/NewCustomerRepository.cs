﻿using MyStore.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStore.Data
{
    public  class NewCustomerRepository
    {
        public Customer Add(Customer customer )
        {
            throw new NotImplementedException();
        }

        public int Delete(Customer customer)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Customer> GetAll(int page)
        {
            throw new NotImplementedException();
        }

        public Customer? GetCategoryById(int id)
        {
            throw new NotImplementedException();
        }

        public Customer Update(Customer customer)
        {
            throw new NotImplementedException();
        }



    }
}
