﻿using MyStore.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStore.Data
{
    
        public class NewCategoryRepository // : ICategoryRepository
        {
            public Category Add(Category category)
            {
                throw new NotImplementedException();
            }

            public int Delete(Category category)
            {
                throw new NotImplementedException();
            }

            public IEnumerable<Category> GetAll(int page)
            {
                throw new NotImplementedException();
            }

            public Category? GetCategoryById(int id)
            {
                throw new NotImplementedException();
            }

            public Category Update(Category category)
            {
                throw new NotImplementedException();
     
            }
}       }


