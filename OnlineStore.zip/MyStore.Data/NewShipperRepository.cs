﻿using MyStore.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStore.Data
{
    
        public class NewShipperRepository // : IShipperRepository
        {
            public Shipper AddShipper(Shipper shipper)
            {
                throw new NotImplementedException();
            }

            public int DeleteShipper(Shipper shipper)
            {
                throw new NotImplementedException();
            }

            public IEnumerable<Shipper> GetAllShippers()
            {
                throw new NotImplementedException();
            }

            public Shipper? GetShipperById(int id)
            {
                throw new NotImplementedException();
            }

            public Shipper UpdateShipper(Shipper shipper)
            {
                throw new NotImplementedException();

            }
        }
    
}
