﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStore.Data.Classes
{
    public class CalculatorTests
    {
        private readonly Calculator calculator;
       public CalculatorTests() 
       { 
        calculator=new Calculator();
       }
    }
}
