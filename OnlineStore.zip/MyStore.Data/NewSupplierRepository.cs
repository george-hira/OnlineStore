﻿using MyStore.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStore.Data
{
    public class NewSupplierRepository
    {
        public Supplier Add(Supplier supplier)
        {
            throw new NotImplementedException();
        }

        public int Delete(Supplier supplier)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Supplier> GetAll(int page)
        {
            throw new NotImplementedException();
        }

        public Supplier? GetSupplieryById(int id)
        {
            throw new NotImplementedException();
        }

        public Supplier Update(Supplier supplier)
        {
            throw new NotImplementedException();
        }
    }

}

