﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStore.Tests.Unit.Classes
{
    public class Calculator
    {
        public int Sum(int x, int y)
        {
            return x + y;   
        }

        public int Multiply(int x, int factor)
        {
            return x * factor;
        }
    }
}
